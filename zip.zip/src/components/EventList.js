import React from 'react';
import BuyTicket from './BuyTicket';

const EventList = ({ events }) => (
  <div>
    <h2>Upcoming Events</h2>
    {events.map(event => (
      <div key={event._id} className="event-card">
        <h3>{event.title}</h3>
        <p>{event.description}</p>
        <p>Date: {new Date(event.date).toLocaleString()}</p>
        <p>Location: {event.location}</p>
        <p>Price: R{event.price}</p>
        <p>Tickets Left: {event.ticketsAvailable}</p>
        <BuyTicket event={event} />
      </div>
    ))}
  </div>
);

export default EventList;

