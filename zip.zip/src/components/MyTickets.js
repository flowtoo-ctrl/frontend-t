import React, { useState, useEffect } from 'react';
import axios from 'axios';

const MyTickets = () => {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const res = await axios.get('/api/tickets/my');
        setTickets(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchTickets();
  }, []);

  if (loading) return <div>Loading your tickets...</div>;
  if (tickets.length === 0) return <div>You haven't bought any tickets yet.</div>;

  return (
    <div style={{ padding: '20px', maxWidth: '900px', margin: '0 auto' }}>
      <h1 style={{ textAlign: 'center', color: '#2c3e50' }}>My Tickets</h1>

      {tickets.map(ticket => (
        <div key={ticket._id} style={{
          background: 'white',
          borderRadius: '8px',
          overflow: 'hidden',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
          marginBottom: '40px'
        }}>
          {/* Header - red/pink top bar */}
          <div style={{
            background: 'linear-gradient(90deg, #c2185b, #d81b60)',
            color: 'white',
            padding: '15px',
            textAlign: 'center'
          }}>
            <h2 style={{ margin: 0, fontSize: '1.6rem' }}>{ticket.event?.title || 'Event Title'}</h2>
          </div>

          {/* Main content */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            padding: '25px',
            gap: '30px'
          }}>
            {/* Left info */}
            <div style={{ flex: 1 }}>
              <p style={{ margin: '8px 0', fontSize: '1.1rem' }}>
                <strong>Location:</strong> {ticket.event?.location || 'Venue TBA'}
              </p>
              <p style={{ margin: '8px 0', fontSize: '1.1rem' }}>
                <strong>Date:</strong> {ticket.event?.date ? new Date(ticket.event.date).toLocaleDateString('en-ZA') : 'TBA'}
              </p>
              <p style={{ margin: '15px 0 5px', fontSize: '1.3rem', fontWeight: 'bold' }}>
                General Ticket
              </p>
              <p style={{ fontSize: '1.4rem', fontWeight: 'bold' }}>
                R {ticket.event?.price?.toFixed(2) || '0.00'}
              </p>

              <p style={{ color: '#d32f2f', fontWeight: 'bold', margin: '15px 0' }}>
                Only valid if purchased through Ticket G channel.
              </p>

              <p style={{ margin: '10px 0' }}>{ticket.buyerEmail}</p>
              <p style={{ fontSize: '0.95rem', color: '#555' }}>
                Purchase Ref: {ticket.paymentId.substring(0, 8)}
              </p>
            </div>

            {/* Right QR */}
            <div style={{ textAlign: 'center' }}>
              <img 
                src={ticket.qrCode} 
                alt="QR Code" 
                style={{ width: '180px', height: '180px', border: '6px solid #000', borderRadius: '8px' }}
              />
            </div>
          </div>

          {/* Pink footer with sponsor bullets */}
          <div style={{
            background: 'linear-gradient(90deg, #c2185b, #d81b60)',
            color: 'white',
            padding: '20px',
            textAlign: 'center'
          }}>
            <p style={{ fontWeight: 'bold', marginBottom: '10px' }}>You can use us too.</p>
            <ul style={{ listStyle: 'none', padding: 0, margin: '10px 0' }}>
              <li>• Our rates are lower than you think!</li>
              <li>• If you don't charge; we don't charge</li>
              <li>• Simple & easy - get loaded in 15 min!</li>
            </ul>
            <div style={{ fontWeight: 'bold', marginTop: '15px' }}>
              Ticket G BOX OFFICE
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MyTickets;