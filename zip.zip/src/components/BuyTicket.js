import React, { useState } from 'react';

const BuyTicket = ({ event }) => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleBuy = async () => {
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      alert('Please enter a valid email');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/payments/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId: event._id, email })
      });

      if (!res.ok) {
        const err = await res.json();
        alert(err.error || 'Payment failed');
        setLoading(false);
        return;
      }

      const { paymentData, endpoint } = await res.json();

      const form = document.createElement('form');
      form.method = 'POST';
      form.action = endpoint;

      Object.entries(paymentData).forEach(([k, v]) => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = k;
        input.value = v;
        form.appendChild(input);
      });

      document.body.appendChild(form);
      form.submit();
    } catch (err) {
      alert('Network error');
      setLoading(false);
    }
  };

  return (
    <div style={{ marginTop: '15px' }}>
      <input
        type="email"
        placeholder="Your email address"
        value={email}
        onChange={e => setEmail(e.target.value)}
        style={{ padding: '10px', width: '250px', marginRight: '10px' }}
      />
      <button onClick={handleBuy} disabled={loading || event.ticketsAvailable <= 0}>
        {loading ? 'Processing...' : 'Buy Ticket'}
      </button>
      {event.ticketsAvailable <= 0 && <p style={{color:'red'}}>Sold out</p>}
    </div>
  );
};

export default BuyTicket;

