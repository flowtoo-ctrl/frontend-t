import React, { useState } from 'react';
import axios from 'axios';

const CreateEvent = ({ onEventCreated }) => {
  const [form, setForm] = useState({ title: '', description: '', date: '', location: '', price: '', ticketsAvailable: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/api/events', {
        ...form,
        price: Number(form.price),
        ticketsAvailable: Number(form.ticketsAvailable)
      });
      onEventCreated(res.data);
      setForm({ title: '', description: '', date: '', location: '', price: '', ticketsAvailable: '' });
    } catch (err) {
      alert('Error creating event');
    }
  };

  return (
    <div>
      <h2>Create Event</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Title" value={form.title} onChange={e => setForm({...form, title: e.target.value})} required />
        <textarea placeholder="Description" value={form.description} onChange={e => setForm({...form, description: e.target.value})} />
        <input type="datetime-local" value={form.date} onChange={e => setForm({...form, date: e.target.value})} required />
        <input placeholder="Location" value={form.location} onChange={e => setForm({...form, location: e.target.value})} />
        <input type="number" placeholder="Price (R)" value={form.price} onChange={e => setForm({...form, price: e.target.value})} required />
        <input type="number" placeholder="Tickets Available" value={form.ticketsAvailable} onChange={e => setForm({...form, ticketsAvailable: e.target.value})} required />
        <button type="submit">Create</button>
      </form>
    </div>
  );
};

export default CreateEvent;

