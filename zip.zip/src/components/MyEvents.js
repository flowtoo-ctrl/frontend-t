import React, { useState, useEffect } from 'react';
import axios from 'axios';

const MyEvents = () => {
  const [events, setEvents] = useState([]);
  const [updateForms, setUpdateForms] = useState({});

  useEffect(() => {
    fetchMyEvents();
  }, []);

  const fetchMyEvents = async () => {
    try {
      const res = await axios.get('/api/events/my');
      setEvents(res.data);
    } catch (err) {
      alert('Error fetching your events');
    }
  };

  const handleUpdate = async (id, newAvailable) => {
    try {
      const res = await axios.put(`/api/events/${id}`, { ticketsAvailable: newAvailable });
      fetchMyEvents(); // refresh
    } catch (err) {
      alert('Error updating');
    }
  };

  return (
    <div>
      <h2>My Created Events</h2>
      {events.map(event => (
        <div key={event._id} className="event-card">
          <h3>{event.title}</h3>
          <p>Tickets Sold: {event.initialTickets - event.ticketsAvailable}</p>
          <p>Tickets Left: {event.ticketsAvailable}</p>
          <form onSubmit={(e) => {
            e.preventDefault();
            handleUpdate(event._id, updateForms[event._id] || event.ticketsAvailable);
          }}>
            <input
              type="number"
              placeholder="New Tickets Available"
              value={updateForms[event._id] || event.ticketsAvailable}
              onChange={e => setUpdateForms({...updateForms, [event._id]: Number(e.target.value)})}
            />
            <button type="submit">Update Tickets</button>
          </form>
        </div>
      ))}
    </div>
  );
};

export default MyEvents;

