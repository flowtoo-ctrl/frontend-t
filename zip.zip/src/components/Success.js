import React, { useEffect } from 'react';
import confetti from 'canvas-confetti'; // npm install canvas-confetti

const Success = () => {
  useEffect(() => {
    // Confetti animation on load
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 }
    });
  }, []);

  return (
    <div className="success-page">
      <div className="success-card">
        <h1>Payment Successful! 🎉</h1>
        <p className="thank-you">Thank you for trusting Ticket G!</p>
        <p>Your ticket (with QR code) has been sent to your email.</p>
        <p>Check your inbox (and spam folder) for the full ticket.</p>

        <div className="quick-actions">
          <a href="/" className="btn primary">Back to Events</a>
          <a href="/my-tickets" className="btn secondary">View My Tickets</a>
        </div>

        <div className="support-text">
          <p>Need help? Contact us at support@ticketg.co.za</p>
        </div>
      </div>
    </div>
  );
};

export default Success;