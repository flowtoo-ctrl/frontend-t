import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { FaBars, FaShoppingCart, FaUser, FaMoon, FaSun } from 'react-icons/fa';
import axios from 'axios';
import EventList from './components/EventList';
import CreateEvent from './components/CreateEvent';
import MyEvents from './components/MyEvents';
import MyTickets from './components/MyTickets';
import Success from './components/Success';
import Login from './components/Login';
import Signup from './components/Signup';
import './index.css';

function App() {
  const [user, setUser] = useState(null);
  const [showMenu, setShowMenu] = useState(false);
  const [darkMode, setDarkMode] = useState(false); // ← Dark mode state
  const [events, setEvents] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      const storedUser = localStorage.getItem('user');
      if (storedUser) setUser(JSON.parse(storedUser));
    }
    fetchEvents();

    // Load dark mode preference
    const savedMode = localStorage.getItem('darkMode') === 'true';
    setDarkMode(savedMode);
  }, []);

  useEffect(() => {
    // Apply dark mode to body
    document.body.classList.toggle('dark-mode', darkMode);
    localStorage.setItem('darkMode', darkMode);
  }, [darkMode]);

  const fetchEvents = async () => {
    try {
      const res = await axios.get('/api/events');
      setEvents(res.data);
    } catch (err) {
      console.error('Failed to load events:', err);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    delete axios.defaults.headers.common['Authorization'];
    setUser(null);
    window.location.href = '/';
  };

  const Navbar = () => (
    <nav className="navbar">
      <div className="left">
        <FaBars
          onClick={() => setShowMenu(!showMenu)}
          style={{ cursor: 'pointer', fontSize: '24px' }}
        />
      </div>

      <span className="logo">Ticket G</span>

      <div className="right">
        {/* Dark mode toggle button */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            fontSize: '24px',
            color: 'white',
            marginRight: '15px'
          }}
        >
          {darkMode ? <FaSun /> : <FaMoon />}
        </button>

        <FaShoppingCart
          style={{ fontSize: '24px', cursor: 'pointer', marginRight: '15px' }}
          onClick={() => alert('Shopping Cart – coming soon!')}
        />

        <FaUser
          onClick={() => user ? handleLogout() : window.location.href = '/login'}
          style={{ cursor: 'pointer', fontSize: '24px' }}
        />
      </div>

      {showMenu && (
        <div className="menu-dropdown">
          <div className="menu-item">
            Profile: {user ? user.email : 'Guest'}
          </div>

          {user && (
            <Link to="/create-event" className="menu-item" onClick={() => setShowMenu(false)}>
              Create Event
            </Link>
          )}

          <Link to="/my-events" className="menu-item" onClick={() => setShowMenu(false)}>
            My Events
          </Link>

          <Link to="/my-tickets" className="menu-item" onClick={() => setShowMenu(false)}>
            My Tickets
          </Link>

          <div
            className="menu-item"
            onClick={() => {
              alert('Shopping Cart – coming soon!');
              setShowMenu(false);
            }}
          >
            Cart
          </div>
        </div>
      )}
    </nav>
  );

  return (
    <Router>
      <Navbar />

      <div className={`container ${darkMode ? 'dark' : ''}`}>
        <Routes>
          <Route path="/" element={<EventList events={events} />} />

          <Route
            path="/create-event"
            element={user ? <CreateEvent onEventCreated={fetchEvents} /> : <p>Please login to create events</p>}
          />

          <Route
            path="/my-events"
            element={user ? <MyEvents /> : <p>Please login first</p>}
          />

          <Route
            path="/my-tickets"
            element={user ? <MyTickets /> : <p>Please login to view your tickets</p>}
          />

          <Route path="/success" element={<Success />} />

          <Route path="/login" element={<Login setUser={setUser} />} />
          <Route path="/signup" element={<Signup setUser={setUser} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;